﻿namespace GeneralKnowledge.Test.App.Tests
{
    public interface ITest
    {
        void Run();
    }
}
