﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneralKnowledge.Test.App.Tests
{
    class Samples
    {
        public IList<SampleData> samples { get; set; }
    }
}
