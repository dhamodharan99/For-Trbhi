﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Linq;

namespace GeneralKnowledge.Test.App.Tests
{
    /// <summary>
    /// Basic data retrieval from JSON test
    /// </summary>
    public class JsonReadingTest : ITest
    {
        public string Name { get { return "JSON Reading Test";  } }

        public void Run()
        {
            Console.WriteLine("..........." );
            //var jsonData = Resources.SamplePoints; 

            // TODO: 
            // Determine for each parameter stored in the variable below, the average value, lowest and highest number.
            // Example output
            // parameter   LOW AVG MAX
            // temperature   x   y   z
            // pH            x   y   z
            // Chloride      x   y   z
            // Phosphate     x   y   z
            // Nitrate       x   y   z

            PrintOverview();
        }
        private void PrintOverview()
        {
            string workingDirectory = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            string json;
            using (StreamReader r = new StreamReader(projectDirectory + "\\Resources\\SamplePoints.json"))
            {
                json = r.ReadToEnd();
            }
            var getData = JsonConvert.DeserializeObject<Samples>(json);

            Console.WriteLine("{0}", "parameter" + "\t" + "Low" + "\t" + "Avg" + "\t" + "Max");
            Console.WriteLine("{0}", "temperature" + "\t" + getData.samples.Min(a => a.temperature).ToString("00.##") + "\t" + getData.samples.Average(a => a.temperature).ToString("00.##") + "\t" + getData.samples.Max(a => a.temperature).ToString("00.##"));
            Console.WriteLine("{0}", "pH" + "\t" + "\t" + getData.samples.Min(a => a.pH).ToString("00.##") + "\t" + getData.samples.Average(a => a.pH).ToString("00.##") + "\t" + getData.samples.Max(a => a.pH).ToString("00.##"));
            Console.WriteLine("{0}", "Chloride" + "\t" + getData.samples.Min(a => a.chloride).ToString("00.##") + "\t" + getData.samples.Average(a => a.chloride).ToString("00.##") + "\t" + getData.samples.Max(a => a.chloride).ToString("00.##"));
            Console.WriteLine("{0}", "Phosphate" + "\t" + getData.samples.Min(a => a.phosphate).ToString("00.##") + "\t" + getData.samples.Average(a => a.phosphate).ToString("00.##") + "\t" + getData.samples.Max(a => a.phosphate).ToString("00.##"));
            Console.WriteLine("{0}", "Nitrate" + "\t" + "\t" + getData.samples.Min(a => a.nitrate).ToString("00.##") + "\t" + getData.samples.Average(a => a.nitrate).ToString("00.##") + "\t" + getData.samples.Max(a => a.nitrate).ToString("00.##"));
        }
    }
}
