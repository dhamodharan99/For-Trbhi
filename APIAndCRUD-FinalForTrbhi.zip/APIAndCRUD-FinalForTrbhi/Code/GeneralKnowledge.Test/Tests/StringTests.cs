﻿using System;
using System.Linq;

namespace GeneralKnowledge.Test.App.Tests
{
    /// <summary>
    /// Basic string manipulation exercises
    /// </summary>
    public class StringTests : ITest
    {
        public void Run()
        {
            // TODO
            // Complete the methods below

            AnagramTest();
            GetUniqueCharsAndCount();
        }

        private void AnagramTest()
        {
            var word = "stop";
            var possibleAnagrams = new string[] { "test", "tops", "spin", "post", "mist", "step" };
                
            foreach (var possibleAnagram in possibleAnagrams)
            {
                Console.WriteLine(string.Format("{0} > {1}: {2}", word, possibleAnagram, possibleAnagram.IsAnagram(word)));
            }
            Console.WriteLine();
        }

        private void GetUniqueCharsAndCount()
        {
            var word = "xxzwxzyzzyxwxzyxyzyxzyxzyzyxzzz";
            string answer = new String(word.Distinct().ToArray());
            Console.WriteLine("Unique Chars: ");
            Console.WriteLine(answer);
            Console.WriteLine();
            Console.WriteLine("No of occurrences for each character: ");
            var charLookup = word.Where(char.IsLetterOrDigit).ToLookup(c => c); // IsLetterOrDigit to exclude the space

            foreach (var c in charLookup)
                Console.WriteLine("Char:{0} Count:{1}", c.Key, charLookup[c.Key].Count());

            Console.WriteLine();
            
            // TODO
            // Write an algorithm that gets the unique characters of the word below 
            // and counts the number of occurrences for each character found
        }
    }

    public static class StringExtensions
    {
        public static bool IsAnagram(this string a, string b)
        {
            // TODO
            // Write logic to determine whether a is an anagram of b
            ///return a.IsAnagram(b);  --- Test this


            //Convert both strings to character arrays.
            //Sort the character arrays in ascending / descending order, but use the same ordering on both of the character sets.
            //Create two strings out of the two sorted character set arrays.
            //Compare the strings.
            //If they are not equal, they are not Anagrams.

            //step 1  
            char[] char1 = a.ToLower().ToCharArray();
            char[] char2 = b.ToLower().ToCharArray();

            //Step 2  
            Array.Sort(char1);
            Array.Sort(char2);

            //Step 3  
            string NewWord1 = new string(char1);
            string NewWord2 = new string(char2);

            //Step 4  
            if (NewWord1 == NewWord2)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }
    }
}
