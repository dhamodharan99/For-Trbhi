﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace AssetAPI.Models
{
    public class AssetDetailContext : DbContext
    {
        public AssetDetailContext(DbContextOptions<AssetDetailContext> options) : base(options)
        {

        }

        public DbSet<AssetDetail> AssetDetails { get; set; }

    }
}
