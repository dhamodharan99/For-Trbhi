export class AssetDetail {
    AssetDetailID :number;
    Asset_id :number;
    file_name: string;
    mime_type: string;
    created_by: string;
    email: string;
    country: string;
    description: string;
}