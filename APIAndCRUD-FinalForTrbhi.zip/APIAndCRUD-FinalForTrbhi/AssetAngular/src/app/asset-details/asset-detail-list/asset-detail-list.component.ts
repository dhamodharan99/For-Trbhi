import { AssetDetail } from './../../shared/Asset-detail.model';
import { AssetDetailService } from './../../shared/Asset-detail.service';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-asset-detail-list',
  templateUrl: './asset-detail-list.component.html',
  styles: []
})

export class AssetDetailListComponent implements OnInit {

  constructor(private service: AssetDetailService,
    private toastr: ToastrService) { }

  ngOnInit() {
    this.service.refreshList();
  }

  populateForm(pd: AssetDetail) {
    this.service.formData = Object.assign({}, pd);
  }

  onDelete(Asset_id) {
    if (confirm('Are you sure to delete this record ?')) {
      this.service.deleteAssetDetail(Asset_id)
        .subscribe(res => {
          debugger;
          this.service.refreshList();
          this.toastr.warning('Deleted successfully', 'Asset Detail Register');
        },
          err => {
            debugger;
            console.log(err);
          })
    }
  }

}
